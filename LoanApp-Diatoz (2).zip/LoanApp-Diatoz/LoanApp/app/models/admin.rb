class Admin < ApplicationRecord
# Logic
end
