// app/assets/config/manifest.js

//= link_tree ../images
//= link_directory ../javascripts .js
//= link_directory ../stylesheets .css
//= link controllers/application.js
  //= link controllers/hello_controller.js
    //= link controllers/index.js