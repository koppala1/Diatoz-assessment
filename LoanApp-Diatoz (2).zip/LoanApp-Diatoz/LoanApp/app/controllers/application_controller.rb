class ApplicationController < ActionController::Base
end #class end